This folder is intentionally empty.
The completed versions of the exercise files are in the Solutions folder.

There are free resources for this chapter in the Free Exercise Files,
including the open source JDBC drivers for HyperSQL (HSQLDB) and MySQL.