package com.lynda.javatraining.db;

public enum DBType {
	HSQLDB, MYSQL
}
